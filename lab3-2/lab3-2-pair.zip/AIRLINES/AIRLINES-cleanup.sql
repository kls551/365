-- Kaitlin Bleich kbleich / Kyaw Soe ksoe
DROP TABLE Airlines;
DROP TABLE Airports100;
DROP TABLE Flights;
